
package com.gieseckedevrient.android.hellosmartcard;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.telephony.IccOpenLogicalChannelResponse;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
//import org.simalliance.openmobileapi.*;


public class MainActivity extends Activity /*implements SEService.CallBack*/ {

	final String LOG_TAG = "HelloSmartcard";

	//private SEService seService;

	private Button button;
	TextView _textview = null;
	ScrollView _scrollview = null;

	private void logText(String message) {
		_scrollview.post(new Runnable() {
			public void run() {
				_scrollview.fullScroll(ScrollView.FOCUS_DOWN);
			}

		});
		_textview.append(message);
	}

	private String getScapiVersion() {
		logText("Reading API versions from mobile:  \n\n");
		try {
			PackageInfo packageInfo = getPackageManager().getPackageInfo("android.smartcard", 0);
			logText("android.smartcard:" + packageInfo.versionName + "\n\n");
			return packageInfo.versionName;
		} catch (PackageManager.NameNotFoundException e1) {
			try {
				PackageInfo packageInfo =  getPackageManager().getPackageInfo("org.simalliance.openmobileapi.service", 0);
				logText("org.simalliance.openmobileapi.service:" + packageInfo.versionName + "\n\n");
				return packageInfo.versionName;
			} catch (PackageManager.NameNotFoundException e2) {
				try {
					PackageInfo packageInfo = getPackageManager().getPackageInfo("com.sonyericsson.smartcard", 0);
					logText("com.sonyericsson.smartcard:" + packageInfo.versionName + "\n\n");
					return packageInfo.versionName;
				} catch (PackageManager.NameNotFoundException e3) {
					logText("3:" + "no lib supported" + "\n");
					return "";
				}
			}
		}
	}

	private void api21(){
        logText("\nAndroid API version: " + Build.VERSION.SDK_INT);
        //if(tm.hasCarrierPrivileges()) {
        if(true){
            try {
                TelephonyManager  tm=(TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);

                logText("\nIMSI: " + tm.getSubscriberId());
                logText("\nICCID: " + tm.getSimSerialNumber());

                logText("\nTrying API21: ");
                IccOpenLogicalChannelResponse resp = tm.iccOpenLogicalChannel("D2760001180002FF49502589C0019B01");
                logText(resp.toString());

                logText("\nTrying to send APDU");

                String respApdu = tm.iccTransmitApduLogicalChannel(resp.getChannel(), (int) 0x90, (int) 0x10, (int) 0x00, (int) 0x00, (int) 0x00, null);
                logText("\nresponse: " + respApdu);

				logText("\nInput data to encrypt: all 0");

				respApdu = tm.iccTransmitApduLogicalChannel(resp.getChannel(), (int) 0x00, (int) 0x00, (int) 0x00, (int) 0x00, (int) 0x10,
						"00000000000000000000000000000000" + "00");
				logText("\nresponseEnc: " + respApdu);

				logText("\nInput data to decrypt: received msg");
				String toDecrypt = respApdu.substring((int)0, (int)16*2);//*2 is because data is ASCII

				respApdu = tm.iccTransmitApduLogicalChannel(resp.getChannel(), (int) 0x00, (int) 0x01, (int) 0x00, (int) 0x00, (int) 0x10,
						toDecrypt + "00");
				logText("\nresponseDec: " + respApdu);

                if (tm.iccCloseLogicalChannel(resp.getChannel())) {
                    logText("\nchannel closed...\n\n");
                }

            } catch (Exception e) {
                logText("\n\n\nException 1: " + e + "\n");
            }
        }else{
            logText("no carrier priviledge\n");
        }
    }

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
		layout.setLayoutParams(new LayoutParams(
				LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT));

		_scrollview = new ScrollView(this);
		_textview = new TextView(this);
		//_textview.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        Display disp = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        disp.getSize(size);
        int windowWidth = size.x;
        int windowHeight = size.y;

        _textview.setLayoutParams(new LayoutParams(windowWidth*3/4, LayoutParams.WRAP_CONTENT));

		_scrollview.addView(_textview);
		layout.addView(_scrollview);
		//setContentView(layout);


        button = new Button(this);
        button.setLayoutParams(new LayoutParams(
                LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT));

        button.setText("Send");
        button.setEnabled(true);
        layout.addView(button);
        setContentView(layout);

		button.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {

                api21();
                button.setVisibility(View.VISIBLE);
                button.setEnabled(true);

				/*try {
					Log.i(LOG_TAG, "Retrieve available readers...");
					Reader[] readers = seService.getReaders();
					if (readers.length < 1)
						return;

					Log.i(LOG_TAG, "Create Session from the first reader...");
					Session session = readers[0].openSession();

					Log.i(LOG_TAG, "Create logical channel within the session...");
					Channel channel = session.openLogicalChannel(new byte[] {
							(byte) 0xD2, 0x76, 0x00, 0x01, 0x18, 0x00, 0x02,
							(byte) 0xFF, 0x49, 0x50, 0x25, (byte) 0x89,
							(byte) 0xC0, 0x01, (byte) 0x9B, 0x01 });

					Log.i(LOG_TAG, "Send HelloWorld APDU command");
					byte[] respApdu = channel.transmit(new byte[] {
							(byte) 0x90, 0x10, 0x00, 0x00, 0x00 });

					channel.close();

					// Parse response APDU and show text but remove SW1 SW2 first
					byte[] helloStr = new byte[respApdu.length - 2];
					System.arraycopy(respApdu, 0, helloStr, 0, respApdu.length - 2);
					Toast.makeText(MainActivity.this, new String(helloStr), Toast.LENGTH_LONG).show();
				} catch (Exception e) {
					Log.e(LOG_TAG, "Error occured:", e);
					logText("Exception 2:" + e);
					return;
				}*/
			}
		});



		getScapiVersion();

        /*
		try {
			Log.i(LOG_TAG, "creating SEService object");
			logText("creating SEService object");
			seService = new SEService(this, this);
			logText("...done\n");
		} catch (SecurityException e) {
			Log.e(LOG_TAG, "Binding not allowed, uses-permission org.simalliance.openmobileapi.SMARTCARD?");
			logText("Binding not allowed, uses-permission org.simalliance.openmobileapi.SMARTCARD?");
		} catch (Exception e) {
			Log.e(LOG_TAG, "Exception: " + e.getMessage());
			logText("Exception: " + e.getMessage());
		}*/

	}

	@Override
	protected void onDestroy() {
		/*if (seService != null && seService.isConnected()) {
			seService.shutdown();
		}*/
		super.onDestroy();
	}

	/*public void serviceConnected(SEService service) {
		Log.i(LOG_TAG, "seviceConnected()");
		logText("serviceConnected()\n");
		button.setEnabled(true);
	}*/
}
