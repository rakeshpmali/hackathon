/*******************************************************************************
 * Copyright (c) 1999, 2014 IBM Corp.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * and Eclipse Distribution License v1.0 which accompany this distribution. 
 *
 * The Eclipse Public License is available at 
 *    http://www.eclipse.org/legal/epl-v10.html
 * and the Eclipse Distribution License is available at 
 *   http://www.eclipse.org/org/documents/edl-v10.php.
 */
package org.eclipse.paho.android.service.sample;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import org.eclipse.paho.android.service.sample.R;

/**
 * This fragment displays the history information for a client
 *
 */
public class HistoryFragment extends  Fragment {

  private String temperatureText;
  private String humidityText;

  /** Client handle to a {@link Connection} object **/
  String clientHandle = null;
  /**
   * @see android.support.v4.app.Fragment#onCreateView(android.view.LayoutInflater, android.view.ViewGroup, android.os.Bundle)
   */
  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container,
                           Bundle savedInstanceState) {
    clientHandle = getArguments().getString("handle");



    return LayoutInflater.from(getActivity()).inflate(R.layout.hist, null);

  }

  public void refresh() {
    Connection connection = Connections.getInstance(getActivity()).getConnection(clientHandle);

    ((TextView) getActivity().findViewById(R.id.currTempTextView)).setText(connection.getTemperature());
    ((TextView) getActivity().findViewById(R.id.CurrHumTextView)).setText(connection.getHumidity());
    ((TextView) getActivity().findViewById(R.id.CurrReqTempTextView)).setText(connection.getRequestedTemp());
    ((TextView) getActivity().findViewById(R.id.CurrRelayStateTextView)).setText(connection.getRelayState());
  }

  public void update(String Temp,String Humidity) {

    temperatureText = Temp;
    humidityText = Humidity;

  }
}


